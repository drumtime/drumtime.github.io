$(function () {
	var slides      = $('#slides'),
		scroller    = $('#scroller'),
		indicators  = $('#indicators li'),
		slide_width = slides.children('li').outerWidth(),
		timer       = null,
		scrolling   = false
		slide_idx   = 0,
		num_slides  = slides.children('li').length,
        back        = $('#back'),
        forward     = $('#forward');	
		
	
	var scroll_to = function (slide_index) {
		slide_idx = slide_index;
		
        back.attr('disabled', null);
        forward.attr('disabled', null);

		// some boundary checking
		if(slide_idx >= num_slides - 1) {
            slide_idx = num_slides - 1;
            forward.attr('disabled', 'true');
        }
		if(slide_idx <= 0) {
            slide_idx = 0;
            back.attr('disabled', 'true');
        }

		// scroll and set indicator
		slides.css('left', (-1 * slide_idx * slide_width)+"px");
		indicators.removeClass('current');
		$(indicators[slide_idx]).addClass('current');
	}
	
	var next_slide = function () {
		scroll_to(slide_idx+1);
	}
	
	var prev_slide = function () {
		scroll_to(slide_idx-1);
	}
	

    // -- add behavior 
    // scrolling (two finger swipe)
	scroller.on('mousewheel', function (event) {
		if(timer != null) clearTimeout(timer);

        var dx = event.originalEvent.wheelDeltaX;
        if(Math.abs(dx) < 4) return;

		timer = setTimeout(function () {
			scrolling = false;
			timer     = null;
		}, 50);
		
		if(!scrolling) {
			scrolling = true;
			(dx > 0) ? prev_slide() : next_slide(); 
			scroll_to(slide_idx);
		}
	});

    // dragging 
    scroller.on('mousedown', function (event) {
        var xpos     = event.pageX;
        var slides_x = parseInt(slides.css('left')); 

        // remove css transitions
        var transition = slides.css('-webkit-transition');
        slides.css('-webkit-transition', 'none');

        var update_position = function (event) {
            dx   = xpos - event.pageX;
            xpos = event.pageX;
            slides_x -= dx;
            slides.css('left', slides_x+"px");
        }

        var stop_drag = function (event) {
            $(document).off('mousemove', update_position);
            $(document).off('mouseup', stop_drag);
            slides.css('-webkit-transition', transition);

            var left_edge  = slide_idx * slide_width,
                right_edge = (slide_idx+1) * slide_width,
                clip_left  = -slides_x,
                clip_right = -slides_x + slide_width;

            // calculate offsets as fractions to prev or next slide
            var overlap_right = (clip_right - right_edge) / slide_width,
                overlap_left  = (left_edge - clip_left)  / slide_width;

            // 'snap' to slide if more than 15% visible 
            if(overlap_right > 0.15)
                next_slide();
            else if(overlap_left > 0.15)
                prev_slide();
            else
               slides.css('left', (-slide_idx*slide_width)+"px"); 
        }

        $(document).on('mousemove', update_position);
        $(document).on('mouseup', stop_drag);
    });
    
    // clicks 
	back.on('click', function (event) {
        prev_slide();
    });
    forward.on('click', function (event) {
        next_slide();
    });

	indicators.on('click', function (event) {	
		scroll_to(indicators.index(event.target)*1);
	});
  
    // keys
    $(document).on('keydown', function (event) {
        console.debug(event.which);
        switch(event.which) {
        case 37:
            prev_slide();
            break;
        case 39:
            next_slide();
            break;
        }
    });
});